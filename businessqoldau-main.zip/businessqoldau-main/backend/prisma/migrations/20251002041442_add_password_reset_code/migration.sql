-- AlterTable
ALTER TABLE "public"."password_reset_tokens" ADD COLUMN     "code" TEXT;
