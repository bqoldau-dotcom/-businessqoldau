-- AlterTable
ALTER TABLE "public"."email_verification_tokens" ADD COLUMN     "code" TEXT;
