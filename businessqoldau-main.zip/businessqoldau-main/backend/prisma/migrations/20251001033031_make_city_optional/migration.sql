-- AlterTable
ALTER TABLE "public"."profiles" ALTER COLUMN "city" DROP NOT NULL;
